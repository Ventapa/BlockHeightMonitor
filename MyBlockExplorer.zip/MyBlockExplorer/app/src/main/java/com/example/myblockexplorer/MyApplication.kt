package com.example.myblockexplorer

import android.app.Application

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize global things here, if needed
    }
}
